package com.ffmax.sensitivity.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkGamingColorScheme = darkColorScheme(
    background = CyberBackground,
    surface = CyberSurface,
    primary = CyberPrimary,
    secondary = CyberSecondary,
    onBackground = CyberTextMain,
    onSurface = CyberTextMain
)

@Composable
fun FFMaxTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkGamingColorScheme,
        content = content
    )
}
