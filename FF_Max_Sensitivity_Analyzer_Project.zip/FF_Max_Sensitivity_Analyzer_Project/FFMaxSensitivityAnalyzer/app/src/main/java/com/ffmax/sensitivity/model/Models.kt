package com.ffmax.sensitivity.model

enum class PlayStyle(val label: String) {
    ONE_TAP("ون طاب (Shotgun/Desert)"),
    SPRAY("رش وتثبيت (AR/SMG)"),
    SNIPER("قنص سريع (Sniper Master)")
}

data class DeviceSpecs(
    val modelName: String,
    val ramGb: Int,
    val refreshRateHz: Int,
    val screenDpi: Int
)

data class SensitivityResult(
    val general: Int,
    val redDot: Int,
    val scope2x: Int,
    val scope4x: Int,
    val sniper: Int,
    val freeLook: Int,
    val fireButtonSize: Int,
    val recommendedHud: String,
    val recommendedDpi: Int,
    val graphicsPreset: String,
    val fpsPreset: String
)
