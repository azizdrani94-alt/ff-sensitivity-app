package com.ffmax.sensitivity.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ffmax.sensitivity.analyzer.DeviceAnalyzer
import com.ffmax.sensitivity.model.DeviceSpecs
import com.ffmax.sensitivity.model.PlayStyle
import com.ffmax.sensitivity.model.SensitivityResult
import com.ffmax.sensitivity.ui.theme.*

@Composable
fun CyberAppScreen() {
    val context = LocalContext.current
    val analyzer = remember { DeviceAnalyzer(context) }

    var specs by remember { mutableStateOf<DeviceSpecs?>(null) }
    var selectedStyle by remember { mutableStateOf(PlayStyle.ONE_TAP) }
    var result by remember { mutableStateOf<SensitivityResult?>(null) }

    FFMaxTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = CyberBackground
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "FF MAX SENSITIVITY PRO",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberPrimary,
                    modifier = Modifier.padding(vertical = 12.dp)
                )

                Button(
                    onClick = {
                        specs = analyzer.analyzeSpecs()
                        result = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberSecondary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) {
                    Text("⚡ فحص مواصفات الهاتف", fontSize = 16.sp, color = Color.White)
                }

                AnimatedVisibility(visible = specs != null) {
                    specs?.let { data ->
                        Column(
                            modifier = Modifier
                                .padding(top = 16.dp)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(CyberSurface)
                                .border(1.dp, CyberPrimary.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                .padding(16.dp)
                        ) {
                            Text("📱 الجهاز: ${data.modelName}", color = CyberTextMain)
                            Text("💾 الرام: ${data.ramGb} GB", color = CyberTextSub)
                            Text("🖥️ معدل التحديث: ${data.refreshRateHz} Hz", color = CyberTextSub)
                            Text("📐 كثافة الشاشة: ${data.screenDpi} DPI", color = CyberTextSub)
                        }
                    }
                }

                if (specs != null) {
                    Spacer(modifier = Modifier.height(20.dp))
                    Text("اختر نمط القتال المفصل:", color = CyberTextSub, modifier = Modifier.align(Alignment.Start))
                    Spacer(modifier = Modifier.height(8.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        PlayStyle.values().forEach { style ->
                            FilterChip(
                                selected = selectedStyle == style,
                                onClick = { selectedStyle = style },
                                label = { Text(style.label, color = if (selectedStyle == style) Color.Black else CyberTextMain) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyberPrimary,
                                    containerColor = CyberSurface
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { result = analyzer.calculateSettings(specs!!, selectedStyle) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) {
                        Text("🔥 استخراج الإعدادات الاحترافية", fontSize = 16.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }

                AnimatedVisibility(visible = result != null) {
                    result?.let { settings ->
                        Column(
                            modifier = Modifier
                                .padding(top = 20.dp)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(CyberSurface)
                                .border(1.5.dp, CyberPrimary, RoundedCornerShape(16.dp))
                                .padding(20.dp)
                        ) {
                            Text("🎯 نتائج الحساسية الموصى بها", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = CyberPrimary)
                            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = CyberBackground)

                            StatRow("عام (General)", "${settings.general}")
                            StatRow("النقطة الحمراء (Red Dot)", "${settings.redDot}")
                            StatRow("عدسة 2X", "${settings.scope2x}")
                            StatRow("عدسة 4X", "${settings.scope4x}")
                            StatRow("القناص (Sniper)", "${settings.sniper}")

                            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = CyberBackground)

                            Text("⚙️ إعدادات التحكم والجرافيك", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = CyberSecondary)
                            Spacer(modifier = Modifier.height(8.dp))
                            StatRow("حجم زر الإطلاق", "${settings.fireButtonSize}%")
                            StatRow("تخطيط الأصابع", settings.recommendedHud)
                            StatRow("DPI الآمن", "${settings.recommendedDpi}")
                            StatRow("الجرافيكس", settings.graphicsPreset)
                            StatRow("معدل الأطر (FPS)", settings.fpsPreset)

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val text = "General: ${settings.general}, RedDot: ${settings.redDot}, FireButton: ${settings.fireButtonSize}%, DPI: ${settings.recommendedDpi}"
                                    clipboard.setPrimaryClip(ClipData.newPlainText("FF Settings", text))
                                    Toast.makeText(context, "تم نسخ جميع الإعدادات!", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberSecondary),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("📋 نسخ الإعدادات", color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = CyberTextSub)
        Text(value, color = CyberTextMain, fontWeight = FontWeight.Bold)
    }
}
