package com.ffmax.sensitivity.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBackground = Color(0xFF0F111A)
val CyberSurface = Color(0xFF1B1E2E)
val CyberPrimary = Color(0xFF00E676)
val CyberSecondary = Color(0xFF7C4DFF)
val CyberTextMain = Color(0xFFFFFFFF)
val CyberTextSub = Color(0xFFA0A5C0)
