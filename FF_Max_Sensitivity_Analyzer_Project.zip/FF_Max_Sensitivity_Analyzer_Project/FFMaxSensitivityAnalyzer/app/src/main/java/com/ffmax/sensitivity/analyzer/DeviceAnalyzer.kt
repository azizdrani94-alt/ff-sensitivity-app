package com.ffmax.sensitivity.analyzer

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager
import com.ffmax.sensitivity.model.DeviceSpecs
import com.ffmax.sensitivity.model.PlayStyle
import com.ffmax.sensitivity.model.SensitivityResult

class DeviceAnalyzer(private val context: Context) {

    fun analyzeSpecs(): DeviceSpecs {
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager.getMemoryInfo(memInfo)
        val ramGb = (memInfo.totalMem / (1024 * 1024 * 1024)).toInt()

        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        val display = windowManager.defaultDisplay
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        display.getMetrics(metrics)

        return DeviceSpecs(
            modelName = "${Build.MANUFACTURER.uppercase()} ${Build.MODEL}",
            ramGb = ramGb,
            refreshRateHz = display.refreshRate.toInt(),
            screenDpi = metrics.densityDpi
        )
    }

    fun calculateSettings(specs: DeviceSpecs, style: PlayStyle): SensitivityResult {
        var gen = 90
        var red = 85
        var fireButton = 45
        var hudLayout = "2 الأصابع (Basic)"

        when {
            specs.ramGb <= 4 -> {
                gen = 98
                red = 94
                fireButton = 52
            }
            specs.ramGb in 5..7 -> {
                gen = 88
                red = 84
                fireButton = 48
                hudLayout = "3 أصابع (Claw)"
            }
            else -> {
                gen = 78
                red = 75
                fireButton = 42
                hudLayout = "3 أو 4 أصابع (Pro Claw)"
            }
        }

        when (style) {
            PlayStyle.ONE_TAP -> {
                gen = (gen + 4).coerceAtMost(100)
                red = (red + 5).coerceAtMost(100)
                fireButton -= 3
            }
            PlayStyle.SPRAY -> {
                gen = (gen - 2).coerceAtLeast(60)
                fireButton += 3
            }
            PlayStyle.SNIPER -> {
                gen = (gen - 5).coerceAtLeast(60)
                red = (red - 8).coerceAtLeast(50)
            }
        }

        if (specs.refreshRateHz >= 90) {
            gen = (gen - 3).coerceAtLeast(60)
        }

        val graphics = if (specs.ramGb <= 3) "ناعـم (Smooth)" else if (specs.ramGb <= 6) "قياسي (Standard)" else "فائق (Ultra)"
        val fps = if (specs.refreshRateHz >= 90) "90 FPS / High" else "High FPS"
        val safeDpi = specs.screenDpi + if (specs.ramGb >= 6) 60 else 40

        return SensitivityResult(
            general = gen,
            redDot = red,
            scope2x = (gen - 6).coerceAtLeast(50),
            scope4x = (gen - 10).coerceAtLeast(45),
            sniper = 45,
            freeLook = 75,
            fireButtonSize = fireButton,
            recommendedHud = hudLayout,
            recommendedDpi = safeDpi,
            graphicsPreset = graphics,
            fpsPreset = fps
        )
    }
}
